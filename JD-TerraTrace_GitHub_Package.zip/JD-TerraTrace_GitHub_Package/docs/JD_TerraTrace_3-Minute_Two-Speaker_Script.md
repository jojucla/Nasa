# JD TerraTrace — 3-Minute Two-Speaker Presentation Script

**Target duration:** approximately 3 minutes

## Speaker 1 — Opening and the problem

Hello everyone. We are excited to present **JD TerraTrace**, an intelligent platform for finding environmental changes that are easy to miss.

Our main idea is simple: the average can hide the real story.

For example, a sea temperature may look almost stable when we calculate one average for a whole region. But inside that same region, one area may be getting warmer while another area is getting cooler. If we only look at the average, we may miss an important environmental change.

This is a challenge for Earth science because NASA provides many different datasets, variables, and models. It can be difficult to know which data to choose, where the change is happening, how large it is, and whether it is strong enough to trust.

That is where JD TerraTrace helps.

## Speaker 2 — The solution and the case study

JD TerraTrace connects the discovery process with the analysis process in one clear dashboard.

For our first case study, we focus on the Red Sea. We compare two important variables: **Sea Surface Temperature**, or SST, and **Chlorophyll-a**, which helps us understand changes in ocean biology.

We divide the Red Sea into three areas: north, central, and south. The user can select any area and immediately see its map signal, time trend, statistical result, and relationship with the other variable.

The platform also shows whether the trend is positive, negative, or opposite to another region. This is our key innovation: detecting spatial divergence instead of looking only at one regional average.

## Speaker 1 — NASA connection and scientific method

The platform is connected to NASA’s Common Metadata Repository, or CMR, to discover relevant Earth science collections. We also use official NASA sources such as MODIS ocean-color data, GHRSST sea-surface temperature data, earthaccess, Giovanni, and NASA Harmony.

Behind the interface, the planned scientific workflow includes time-series analysis, trend tests, confidence ranges, and cross-variable comparison. In simple terms, the system does not only ask, “Did the value change?” It also asks, “How fast did it change, where did it change, and can we trust the result?”

## Speaker 2 — Prototype status and closing

Our prototype is honest about its current stage. The NASA metadata connection is live, while the values shown in this first demo are clearly marked as demonstration outputs. This means we do not present simulated values as final scientific results.

The next step is to connect authenticated NASA data files, apply quality filters, and run the full analysis on real satellite measurements.

JD TerraTrace can then expand beyond the Red Sea to coastal zones, forests, ice regions, cities, and any area covered by Earth observation data.

Our goal is to turn complex satellite information into clear, trusted, and useful scientific insight.

Thank you. We are JD TerraTrace — finding the change the average hides.
