# JD TerraTrace

NASA Space Apps Challenge project for detecting hidden Earth system change.

- `code/` — React, TypeScript, Express application source code
- `presentation/` — 7-slide HTML presentation
- `docs/` — project summary, two-speaker script, and NASA sources

The application connects to NASA CMR metadata. Demonstration chart values are clearly labelled in the interface and are not presented as final scientific results.
