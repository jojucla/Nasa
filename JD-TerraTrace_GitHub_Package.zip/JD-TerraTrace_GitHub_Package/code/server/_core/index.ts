import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "jd-terratrace" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  app.get("/api/nasa/collections", async (_req, res) => {
    try {
      const params = new URLSearchParams({
        keyword: "chlorophyll sea surface temperature",
        page_size: "20",
        has_granules: "true",
      });
      const response = await fetch(`https://cmr.earthdata.nasa.gov/search/collections.json?${params.toString()}`, { headers: { Accept: "application/json" } });
      if (!response.ok) throw new Error(`NASA CMR returned ${response.status}`);
      const payload = await response.json() as { feed?: { entry?: Array<{ id: string; title: string; short_name?: string; version_id?: string }> } };
      const entries = (payload.feed?.entry ?? []).slice(0, 12).map((entry) => ({ id: entry.id, title: entry.title, shortName: entry.short_name, version: entry.version_id }));
      res.json({ source: "NASA CMR", count: entries.length, collections: entries, queriedAt: new Date().toISOString() });
    } catch (error) {
      console.error("[NASA CMR] metadata query failed", error);
      res.status(502).json({ source: "NASA CMR", count: 0, collections: [], error: "NASA metadata is temporarily unavailable" });
    }
  });
  registerOAuthRoutes(app);
  app.use("/api/trpc", createExpressMiddleware({ router: appRouter, createContext }));
  if (process.env.NODE_ENV === "development") await setupVite(app, server); else serveStatic(app);
  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}
startServer().catch(error => { console.error(error); process.exit(1); });
