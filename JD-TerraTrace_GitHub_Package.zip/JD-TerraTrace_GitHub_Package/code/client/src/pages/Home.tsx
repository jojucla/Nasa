import { useEffect, useState } from "react";
import { Activity, ArrowUpRight, BarChart3, ChevronRight, CircleHelp, Database, ExternalLink, FileDown, FlaskConical, Layers3, MapPin, Radio, RefreshCw, Satellite, ShieldCheck, SlidersHorizontal, Sparkles, Waves } from "lucide-react";

const sectors = [
  { id: "north", label: "Northern Red Sea", short: "NORTH", lat: "22.5°N", note: "Warmest SST signal in the demonstration series." },
  { id: "central", label: "Central Red Sea", short: "CENTRAL", lat: "19.0°N", note: "Chlorophyll variability is most pronounced here." },
  { id: "south", label: "Southern Red Sea", short: "SOUTH", lat: "15.5°N", note: "Opposite-direction signal highlights spatial divergence." },
] as const;

const trendData = [
  { year: "2015", north: 28.1, central: 28.6, south: 29.0 }, { year: "2016", north: 28.0, central: 28.7, south: 29.1 },
  { year: "2017", north: 28.3, central: 28.8, south: 29.0 }, { year: "2018", north: 28.4, central: 28.9, south: 28.9 },
  { year: "2019", north: 28.6, central: 29.0, south: 28.8 }, { year: "2020", north: 28.7, central: 29.2, south: 28.7 },
  { year: "2021", north: 28.9, central: 29.2, south: 28.6 }, { year: "2022", north: 29.0, central: 29.3, south: 28.5 },
  { year: "2023", north: 29.2, central: 29.5, south: 28.4 }, { year: "2024", north: 29.3, central: 29.6, south: 28.3 },
];

const scatterData = [
  { sst: 28.2, chl: 0.38 }, { sst: 28.5, chl: 0.34 }, { sst: 28.8, chl: 0.31 }, { sst: 29.1, chl: 0.27 },
  { sst: 29.4, chl: 0.24 }, { sst: 29.7, chl: 0.22 }, { sst: 28.7, chl: 0.33 }, { sst: 29.0, chl: 0.29 },
];

const sources = [
  ["Earthdata Search", "Discovery · spatial + temporal", "https://www.earthdata.nasa.gov/engage/open-data-services-software/earthdata-developer-portal/earthdata-search-api"],
  ["MODIS Chlorophyll-a", "Global gridded · mg m⁻³", "https://www.earthdata.nasa.gov/data/catalog/ob-cloud-modisa-l3m-chl-2022.0"],
  ["GHRSST SST", "Sea surface temperature", "https://www.earthdata.nasa.gov/data/projects/ghrsst"],
  ["earthaccess", "Python access · CMR search", "https://www.earthdata.nasa.gov/data/tools/earthaccess"],
  ["Giovanni + Harmony", "Analyze · subset · reproject", "https://www.earthdata.nasa.gov/data/tools/nasa-harmony"],
];

function TrendSvg({ focus }: { focus: "north" | "central" | "south" }) {
  const x = (index: number) => 12 + (index / (trendData.length - 1)) * 676;
  const y = (value: number) => 218 - ((value - 27.5) / 2.5) * 184;
  const path = (key: "north" | "central" | "south") => trendData.map((point, index) => `${x(index)},${y(point[key])}`).join(" ");
  return <svg className="chart-svg" viewBox="0 0 700 250" role="img" aria-label="Annual SST trend chart">
    {[0, 1, 2, 3].map((tick) => <g key={tick}><line x1="12" x2="688" y1={34 + tick * 61} y2={34 + tick * 61} stroke="#243548" /><text x="0" y={38 + tick * 61} fill="#718298" fontSize="10">{(30 - tick * .625).toFixed(1)}</text></g>)}
    <polyline points={path("north")} fill="none" stroke={focus === "north" ? "#ff6b5b" : "#476176"} strokeWidth={focus === "north" ? 3 : 1.5} />
    <polyline points={path("central")} fill="none" stroke={focus === "central" ? "#ff6b5b" : "#476176"} strokeWidth={focus === "central" ? 3 : 1.5} />
    <polyline points={path("south")} fill="none" stroke={focus === "south" ? "#34d5cf" : "#476176"} strokeWidth={focus === "south" ? 3 : 1.5} />
    {trendData.map((point, index) => <text key={point.year} x={x(index)} y="243" textAnchor="middle" fill="#718298" fontSize="9">{point.year}</text>)}
  </svg>;
}

function ScatterSvg() {
  const x = (value: number) => 36 + ((value - 28) / 2) * 340;
  const y = (value: number) => 162 - ((value - .1) / .4) * 130;
  return <svg className="scatter-svg" viewBox="0 0 390 190" role="img" aria-label="SST and chlorophyll relationship scatter plot">
    {[0, 1, 2, 3].map((tick) => <line key={tick} x1="36" x2="376" y1={32 + tick * 43} y2={32 + tick * 43} stroke="#243548" />)}
    {scatterData.map((point, index) => <circle key={index} cx={x(point.sst)} cy={y(point.chl)} r="4.5" fill="#34d5cf" stroke="#0a1823" strokeWidth="2" />)}
    <text x="36" y="184" fill="#718298" fontSize="9">28.0 °C</text><text x="342" y="184" fill="#718298" fontSize="9">30.0 °C</text>
    <text x="2" y="36" fill="#718298" fontSize="9">0.5</text><text x="2" y="165" fill="#718298" fontSize="9">0.1</text>
  </svg>;
}

export default function Home() {
  const [sector, setSector] = useState("central");
  const [variable, setVariable] = useState<"sst" | "chl">("sst");
  const [liveCollections, setLiveCollections] = useState<number | null>(null);
  const [syncing, setSyncing] = useState(false);
  const selected = sectors.find((item) => item.id === sector) ?? sectors[1];

  const seriesKey = selected.id as "north" | "central" | "south";
  const currentMetric = variable === "sst" ? (selected.id === "north" ? "+0.14 °C/yr" : selected.id === "central" ? "+0.11 °C/yr" : "−0.08 °C/yr") : (selected.id === "central" ? "−0.021 mg/m³/yr" : "+0.008 mg/m³/yr");
  const significance = selected.id === "south" ? "p = 0.031 · significant" : selected.id === "central" ? "p = 0.084 · watch" : "p = 0.019 · significant";

  const refreshMetadata = async () => {
    setSyncing(true);
    try {
      const response = await fetch("/api/nasa/collections");
      const payload = await response.json();
      setLiveCollections(payload.count ?? 0);
    } finally {
      setSyncing(false);
    }
  };
  useEffect(() => { refreshMetadata(); }, []);

  return (
    <div className="app-shell">
      <aside className="telemetry-rail">
        <div className="brand-mark"><span>JT</span><i /></div>
        <div className="rail-label">TERRATRACE / 01</div>
        <nav className="rail-nav">
          <a className="active" href="#dashboard"><BarChart3 size={17} /><span>Dashboard</span></a>
          <a href="#map"><MapPin size={17} /><span>Spatial signal</span></a>
          <a href="#sources"><Database size={17} /><span>Provenance</span></a>
          <a href="#method"><FlaskConical size={17} /><span>Methodology</span></a>
        </nav>
        <div className="rail-status"><span className="status-dot" /> System nominal<div className="mono">2026.11.14 / 18:17 UTC</div></div>
      </aside>

      <main className="main-canvas" id="dashboard">
        <header className="topbar">
          <div className="eyebrow"><Satellite size={14} /> EARTH OBSERVATION ANALYTICS <span>·</span> RED SEA CASE STUDY</div>
          <div className="top-actions"><span className="demo-pill"><span className="pulse-dot" /> DEMO ANALYSIS</span><button className="icon-button" aria-label="Help"><CircleHelp size={18} /></button><button className="export-button"><FileDown size={16} /> Export brief</button></div>
        </header>

        <section className="hero-section">
          <div className="hero-copy">
            <div className="hero-kicker">JD TERRATRACE <span className="slash">/</span> SIGNAL INTELLIGENCE</div>
            <h1>Find the change<br /><em>the average hides.</em></h1>
            <p>Spatially divergent environmental trends, surfaced from Earth observation data and validated with statistical context.</p>
            <div className="hero-actions"><button className="primary-button" onClick={() => document.getElementById("map")?.scrollIntoView({ behavior: "smooth" })}>Explore the signal <ArrowUpRight size={17} /></button><span className="hero-caption"><ShieldCheck size={15} /> Provenance-first by design</span></div>
          </div>
          <div className="hero-visual" style={{ backgroundImage: "url('/manus-storage/async-images/gaDNuALYfTOVxOJq8IuVhI/image-1.webp')" }}><div className="hero-overlay" /><div className="orbit-line orbit-a" /><div className="orbit-line orbit-b" /><div className="hero-readout"><span>LIVE METADATA</span><strong>{liveCollections === null ? "—" : liveCollections}</strong><small>NASA CMR collections found</small></div><div className="hero-coords">15.5°N · 41.2°E<br /><span>RED SEA / AOI-001</span></div></div>
        </section>

        <section className="signal-strip">
          <div><span className="strip-label">OBSERVATION WINDOW</span><strong>2015 — 2024</strong></div><div><span className="strip-label">VARIABLES</span><strong>02 / SST + CHL-a</strong></div><div><span className="strip-label">SECTORS</span><strong>03 / NORTH · CENTRAL · SOUTH</strong></div><div><span className="strip-label">DATA STATE</span><strong className="data-state"><span className="status-dot" /> Metadata live · values demo</strong></div>
        </section>

        <section className="section-heading" id="map"><div><span className="section-index">01 / SPATIAL DIVERGENCE</span><h2>One basin. Three signals.</h2></div><div className="control-group"><label>Variable</label><button className={variable === "sst" ? "seg active" : "seg"} onClick={() => setVariable("sst")}>SST</button><button className={variable === "chl" ? "seg active" : "seg"} onClick={() => setVariable("chl")}>CHL-a</button></div></section>
        <section className="analysis-grid">
          <div className="map-card"><div className="card-head"><div><span className="card-kicker"><Layers3 size={14} /> RED SEA / REGIONAL MASK</span><h3>Spatial trend field</h3></div><span className="unit-chip">{variable === "sst" ? "°C / year" : "mg m⁻³ / year"}</span></div><div className="red-sea-map"><div className="map-water" /><div className="map-coast coast-left" /><div className="map-coast coast-right" /><div className="route-line" /><div className={`sector-node node-north ${sector === "north" ? "selected" : ""}`} onClick={() => setSector("north")}><span /><b>NORTH</b><small>+0.14</small></div><div className={`sector-node node-central ${sector === "central" ? "selected" : ""}`} onClick={() => setSector("central")}><span /><b>CENTRAL</b><small>+0.11</small></div><div className={`sector-node node-south ${sector === "south" ? "selected" : ""}`} onClick={() => setSector("south")}><span /><b>SOUTH</b><small>−0.08</small></div><div className="map-compass">N<br /><span>+</span></div><div className="map-legend"><span><i className="legend-coral" /> Positive trend</span><span><i className="legend-cyan" /> Divergent / inverse</span></div></div><div className="map-foot"><span><MapPin size={14} /> Selected: <b>{selected.label}</b></span><span className="mono">GRID 0.25° · MASK v0.3</span></div></div>
          <div className="insight-card"><div className="card-head"><div><span className="card-kicker"><Sparkles size={14} /> INTERPRETATION ENGINE</span><h3>What is changing?</h3></div><span className="signal-badge">SIGNAL FOUND</span></div><div className="insight-main"><div className="big-number">{currentMetric}</div><p>{selected.note}</p></div><div className="insight-list"><div><span>Statistical test</span><strong>Mann–Kendall + Sen’s slope</strong></div><div><span>Significance</span><strong className={significance.includes("significant") ? "coral-text" : "sand-text"}>{significance}</strong></div><div><span>Spatial divergence</span><strong>{selected.id === "south" ? "Detected · inverse to north" : "No inverse trend in sector"}</strong></div></div><div className="caveat"><span>!</span><p>Current values are deterministic demo outputs. Replace with quality-screened NASA granules before scientific publication.</p></div></div>
        </section>

        <section className="section-heading chart-heading"><div><span className="section-index">02 / TEMPORAL TREND</span><h2>Ten years of directional evidence.</h2></div><div className="chart-legend"><span><i className="dot coral" /> {selected.short} focus</span><span><i className="dot muted" /> Other sectors</span></div></section>
        <section className="chart-card"><div className="chart-meta"><div><span className="card-kicker"><Activity size={14} /> SEA SURFACE TEMPERATURE</span><strong>Annual regional mean</strong></div><div className="metric-pair"><span>Δ trend</span><b>{currentMetric}</b></div><div className="metric-pair"><span>confidence</span><b>95% CI</b></div></div><div className="trend-chart"><TrendSvg focus={seriesKey} /></div></section>

        <section className="two-up" id="sources"><div className="relationship-card"><div className="card-head"><div><span className="card-kicker"><Waves size={14} /> CROSS-VARIABLE ANALYSIS</span><h3>SST ↔ Chlorophyll-a</h3></div><span className="corr-chip">r = −0.91</span></div><div className="scatter-wrap"><ScatterSvg /></div><p className="small-note">Demo relationship: warmer surface signal aligns with lower chlorophyll concentration in the selected analysis frame.</p></div><div className="sources-card"><div className="card-head"><div><span className="card-kicker"><Radio size={14} /> PROVENANCE STACK</span><h3>NASA data lineage</h3></div><button className="refresh-button" onClick={refreshMetadata}><RefreshCw size={14} className={syncing ? "spin" : ""} /> Sync</button></div><div className="source-list">{sources.map(([name, detail, url]) => <a key={name} href={url} target="_blank" rel="noreferrer"><div><strong>{name}</strong><span>{detail}</span></div><ExternalLink size={14} /></a>)}</div><div className="live-source"><span className="status-dot" /><span>NASA CMR metadata query</span><b>{liveCollections === null ? "pending" : `${liveCollections} collections`}</b></div></div></section>

        <section className="method-banner" id="method"><div className="method-icon"><SlidersHorizontal size={20} /></div><div><span className="section-index">03 / REPRODUCIBLE METHOD</span><h3>From metadata to evidence, without hiding uncertainty.</h3><p>Earthdata Search discovers collections. earthaccess authenticates and retrieves granules. Harmony subsets and reprojects. JD TerraTrace then applies spatial masks, temporal aggregation, trend estimation, confidence intervals, and multiple-testing correction.</p></div><button className="text-button">View methodology <ChevronRight size={16} /></button></section>
        <footer><span>JD TERRATRACE · SCIENTIFIC PROTOTYPE</span><span>Built for NASA Space Apps Challenge · 2026</span><span className="mono">SOURCE STATUS: {liveCollections === null ? "SYNCING" : "CONNECTED"}</span></footer>
      </main>
    </div>
  );
}
