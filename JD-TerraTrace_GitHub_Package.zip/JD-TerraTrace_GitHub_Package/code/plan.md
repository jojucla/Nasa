# JD TerraTrace — Product Plan

## Product scope
JD TerraTrace is a scientific web prototype for detecting spatially hidden environmental change in the Red Sea. The first case study compares Sea Surface Temperature (SST) and Chlorophyll-a across northern, central, and southern sectors. The interface must distinguish live NASA metadata connectivity from demonstration analysis values.

## Implementation approach
- React + TypeScript + Tailwind frontend with a single dashboard route.
- Express endpoint `/api/nasa/collections` queries the public NASA Common Metadata Repository (CMR) for MODIS chlorophyll-a and GHRSST/SST collections.
- Demonstration analytics are generated deterministically in the browser to show the product behavior without fabricating a claim of live scientific results.
- Recharts provides trend and relationship charts; a CSS/SVG map panel provides a lightweight interactive spatial view with selectable sectors.
- The UI includes source cards and a methodology drawer that link to official NASA Earthdata pages.
- The data model is ready to replace demo arrays with Earthdata/Harmony downloads after Earthdata Login and product-specific access are configured.

## Design direction
Three possible directions were considered: orbital editorial (0.06), mission-control dark (0.04), and coastal observatory light (0.08). Chosen: **mission-control dark**.

### Design Movement
A high-contrast mission-control dashboard: deep ocean-black canvas, thin telemetry lines, compact scientific readouts, and bright coral/sea-glass accents.

### Core Principles
1. Make provenance visible beside every result.
2. Turn statistical uncertainty into a first-class visual signal.
3. Prefer spatial context over decorative UI.
4. Keep the first screen judgeable in under 20 seconds.

### Color Philosophy
Midnight navy communicates observation and rigor. Coral marks anomalous warming or divergence. Sea-glass cyan marks healthy data flow and chlorophyll context. Warm sand is reserved for caveats and human-readable interpretation.

### Layout Paradigm
A left telemetry rail and a wide analytical field. KPI cards sit above a two-column analysis surface; the map is treated as the visual anchor, while charts and interpretation cards orbit it.

### Signature Elements
- A “signal rail” with vertical status markers and source health.
- A red-sea sector map with north/central/south selectable nodes.
- Compact “evidence chips” showing source, unit, period, and significance status.

### Interaction Philosophy
Every selection updates the map, charts, and interpretation together. Controls are explicit and reversible; demo/live state is never hidden.

### Animation
Use subtle 200–350ms transitions on selected sectors, telemetry pulses, and chart reveal. No perpetual motion beyond the source-health pulse.

### Typography System
Use a technical sans stack: IBM Plex Sans / Inter fallback for body, JetBrains Mono for data labels and units. Titles use tight tracking and short lines.

### Brand Essence
A transparent Earth-change cockpit for researchers and hackathon judges. Personality: rigorous, exploratory, honest.

### Brand Voice
Headlines: “Find the signal the average hides.”
Microcopy: “Demo analysis — replace with Earthdata granules for publication-grade results.”

### Wordmark & Logo
A compact “JT” monogram inside a pulse ring, paired with the JD TerraTrace wordmark. The ring represents repeatable observation; the inner pulse represents change.

### Signature Brand Color
Signal coral `#FF6B5B`.

## Project structure
- `client/src/pages/Home.tsx`: dashboard experience and demo analytics.
- `client/src/index.css`: visual system, layout, map, cards, and responsive rules.
- `server/_core/index.ts`: health endpoint and NASA CMR proxy endpoint.
- `public/manus-routes.json`: declared web routes.
- `NASA_SOURCES.md`: verified NASA sources and integration notes.
