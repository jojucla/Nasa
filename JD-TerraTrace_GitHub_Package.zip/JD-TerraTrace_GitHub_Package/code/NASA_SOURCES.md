# NASA Sources for JD TerraTrace

The product uses the following official NASA Earthdata sources:

1. MODIS Chlorophyll-a collection: https://www.earthdata.nasa.gov/data/catalog/ob-cloud-modisa-l3m-chl-2022.0
   - NASA describes the suite as global, gridded surface chlorophyll-a composites.
   - Variable: `chlor_a`, units `mg m^-3`.
   - NASA notes that optically complex coastal and inland waters can carry higher retrieval uncertainty.

2. GHRSST project: https://www.earthdata.nasa.gov/data/projects/ghrsst
   - NASA Earthdata describes GHRSST as a global and regional sea-surface-temperature data ecosystem with quality-control and metadata management through distributed assembly centers.

3. Earthdata Search API: https://www.earthdata.nasa.gov/engage/open-data-services-software/earthdata-developer-portal/earthdata-search-api
   - Supports keyword, spatial, temporal, and facet-based discovery through NASA's Common Metadata Repository.

4. earthaccess: https://www.earthdata.nasa.gov/data/tools/earthaccess
   - NASA describes earthaccess as a community-driven Python library for Earthdata Login, CMR search, and cloud/on-premises downloads.

5. Giovanni: https://www.earthdata.nasa.gov/data/tools/giovanni
   - NASA describes Giovanni as a web application for displaying and analyzing geophysical parameters, including maps, comparison plots, vertical plots, and animations.

6. NASA Harmony: https://www.earthdata.nasa.gov/data/tools/nasa-harmony
   - NASA describes Harmony as a transformation service for geographic, temporal, and variable subsetting, reprojection, and reformatting.

## Integration status
The prototype performs a live metadata query to NASA CMR through `/api/nasa/collections`. The chart values shipped in the first prototype are deterministic demonstration values, clearly labelled in the interface. Publication-grade values require authenticated Earthdata downloads or Harmony jobs, quality flags, spatial masks, temporal aggregation, and reproducible statistical processing.
